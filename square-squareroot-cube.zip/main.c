#include<stdio.h>
#include<math.h>

int main() {
    float num, square, squrt, cube;

    printf("Enter a number: ");
    scanf("%f", &num);
    square = num * num;
    printf("Square of %f is %f\n", num, square);
    squrt = 1.0;
    while (squrt * squrt<= num) {
        squrt += 0.1;
    }
    printf("Square root of %f is %f\n", num, squrt);
    cube = num * num * num;
    printf("Cube of %f is %f\n", num, cube);

    return 0;
}