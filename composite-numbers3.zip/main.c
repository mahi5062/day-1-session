#include <stdio.h>

int main() {
    int arr[100], n, i, j, count = 0;

    printf("enter the number of elements in the array: ");
    scanf("%d", &n);

    printf("enter the elements of the array: ");
    for (i = 0; i < n; i++) 
    {
        scanf("%d", &arr[i]);
    }
    printf("composite numbers in the array: ");
    for (i = 0; i < n; i++) {
        for (j = 2; j <= arr[i] / 2; j++) {
            if (arr[i] % j == 0) {
                printf("%d ", arr[i]);
                count++;
                break;
            }
        }
    }

    printf("\nnumber of composite numbers in the array: %d", count);

    return 0;
}