#include<stdio.h>
int main()
{
    int age,vote,rem;
    
    printf("enter your age");
    scanf("%d",&age);
    if (age>=18)
    {
        printf("you are eligible vote");
    }
    else
    {
        rem=18-age;
        printf("your are not eligible for voting");
        printf("remanning years left:%d",rem);
    }
}