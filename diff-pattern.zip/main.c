#include<stdio.h>
int main()
{
    int rows,i,space,j,coef;
    printf("enter number of rows:");
    scanf("%d",&rows);
    for (i=1;i<=rows;i++)
    {
        for (space=1;space<=rows-i;space++)
        {
            printf("  ");
        }
            for (j = i; j >= 1; j--) 
            {

                printf("%4d",j);
            }
        printf("\n");
    }
    return 0;
}
