#include<stdio.h> 

int main() {
    float i,j,rows;
    float num=0.1;
    printf("enter the no of rows: ");
    scanf("%f",&rows);
    
    for (i=1; i<=rows; i++) {
        for (j=1; j<=i; j++) {
            printf("   %0.1f",j/10);
            num++;
        }
        printf("\n");
    }
    return 0;
}